"use client";
import SparkLinkApp from "../components/SparkLinkApp";  // note the .. goes up one folder

export default function Page() {
  return <SparkLinkApp />;
}
